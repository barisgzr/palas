"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/contexts/language-context"
import { Users, CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

const translations = {
  en: {
    hero: {
      title: "About ConsultPro",
      subtitle: "Your trusted partner in business transformation and growth",
    },
    story: {
      title: "Our Story",
      content: [
        "Founded in 2009, ConsultPro has been at the forefront of business consultancy, helping companies navigate complex challenges and achieve sustainable growth. What started as a small team of passionate consultants has evolved into a comprehensive consultancy firm with expertise across multiple industries.",
        "Our journey began with a simple mission: to provide practical, results-driven solutions that make a real difference to our clients' businesses. Over the years, we've refined our methodologies, expanded our expertise, and built lasting relationships with businesses of all sizes.",
        "Today, we're proud to have helped over 500 companies transform their operations, accelerate growth, and achieve their strategic objectives. Our success is measured not just by our growth, but by the success of our clients.",
      ],
    },
    mission: {
      title: "Our Mission",
      content:
        "To empower businesses with strategic insights, operational excellence, and growth strategies that drive sustainable success. We believe every business has the potential to thrive, and we're here to unlock that potential.",
    },
    values: {
      title: "Our Values",
      items: [
        {
          title: "Excellence",
          description:
            "We strive for excellence in everything we do, delivering high-quality solutions that exceed expectations.",
        },
        {
          title: "Integrity",
          description:
            "We operate with complete transparency and honesty, building trust through our actions and recommendations.",
        },
        {
          title: "Innovation",
          description:
            "We embrace innovative approaches and cutting-edge methodologies to solve complex business challenges.",
        },
        {
          title: "Partnership",
          description:
            "We work as true partners with our clients, invested in their success and committed to long-term relationships.",
        },
      ],
    },
    team: {
      title: "Our Leadership Team",
      members: [
        {
          name: "Sarah Johnson",
          role: "CEO & Founder",
          description:
            "15+ years in strategic consulting with expertise in business transformation and growth strategies.",
        },
        {
          name: "Michael Chen",
          role: "Head of Operations",
          description:
            "Former operations director with deep experience in process optimization and operational excellence.",
        },
        {
          name: "Emily Rodriguez",
          role: "Growth Strategy Director",
          description: "Market expansion specialist with a track record of helping companies scale successfully.",
        },
        {
          name: "David Thompson",
          role: "Senior Consultant",
          description: "Industry veteran with expertise in strategic planning and organizational development.",
        },
      ],
    },
    stats: {
      title: "Our Impact",
      items: [
        { number: "500+", label: "Happy Clients" },
        { number: "1000+", label: "Successful Projects" },
        { number: "15+", label: "Years Experience" },
        { number: "95%", label: "Client Satisfaction" },
      ],
    },
    cta: {
      title: "Ready to Transform Your Business?",
      subtitle: "Let's discuss how we can help you achieve your goals",
      button: "Get Started Today",
    },
  },
  tr: {
    hero: {
      title: "ConsultPro Hakkında",
      subtitle: "İş dönüşümü ve büyümede güvenilir ortağınız",
    },
    story: {
      title: "Hikayemiz",
      content: [
        "2009 yılında kurulan ConsultPro, iş danışmanlığının ön saflarında yer alarak şirketlerin karmaşık zorlukları aşmasına ve sürdürülebilir büyüme elde etmesine yardımcı olmaktadır. Tutkulu danışmanlardan oluşan küçük bir ekip olarak başlayan yolculuğumuz, birden fazla sektörde uzmanlığa sahip kapsamlı bir danışmanlık firmasına dönüştü.",
        "Yolculuğumuz basit bir misyonla başladı: müşterilerimizin işletmelerine gerçek fark yaratan pratik, sonuç odaklı çözümler sunmak. Yıllar boyunca metodolojilerimizi geliştirdik, uzmanlığımızı genişlettik ve her büyüklükteki işletmelerle kalıcı ilişkiler kurduk.",
        "Bugün, 500'den fazla şirketin operasyonlarını dönüştürmesine, büyümesini hızlandırmasına ve stratejik hedeflerine ulaşmasına yardımcı olmaktan gurur duyuyoruz. Başarımız sadece büyümemizle değil, müşterilerimizin başarısıyla ölçülür.",
      ],
    },
    mission: {
      title: "Misyonumuz",
      content:
        "İşletmeleri sürdürülebilir başarı sağlayan stratejik içgörüler, operasyonel mükemmellik ve büyüme stratejileriyle güçlendirmek. Her işletmenin gelişme potansiyeline sahip olduğuna inanıyoruz ve bu potansiyeli ortaya çıkarmak için buradayız.",
    },
    values: {
      title: "Değerlerimiz",
      items: [
        {
          title: "Mükemmellik",
          description:
            "Yaptığımız her şeyde mükemmellik için çaba gösteriyor, beklentileri aşan yüksek kaliteli çözümler sunuyoruz.",
        },
        {
          title: "Dürüstlük",
          description: "Tam şeffaflık ve dürüstlükle çalışıyor, eylemlerimiz ve önerilerimizle güven inşa ediyoruz.",
        },
        {
          title: "İnovasyon",
          description:
            "Karmaşık iş zorluklarını çözmek için yenilikçi yaklaşımları ve son teknoloji metodolojileri benimsiyor.",
        },
        {
          title: "Ortaklık",
          description:
            "Müşterilerimizle gerçek ortaklar olarak çalışıyor, başarılarına yatırım yapıyor ve uzun vadeli ilişkilere odaklanıyoruz.",
        },
      ],
    },
    team: {
      title: "Liderlik Ekibimiz",
      members: [
        {
          name: "Sarah Johnson",
          role: "CEO ve Kurucu",
          description:
            "İş dönüşümü ve büyüme stratejilerinde uzmanlığa sahip 15+ yıllık stratejik danışmanlık deneyimi.",
        },
        {
          name: "Michael Chen",
          role: "Operasyon Başkanı",
          description:
            "Süreç optimizasyonu ve operasyonel mükemmellikte derin deneyime sahip eski operasyon direktörü.",
        },
        {
          name: "Emily Rodriguez",
          role: "Büyüme Stratejisi Direktörü",
          description:
            "Şirketlerin başarılı bir şekilde ölçeklenmesine yardımcı olma konusunda kanıtlanmış geçmişe sahip pazar genişleme uzmanı.",
        },
        {
          name: "David Thompson",
          role: "Kıdemli Danışman",
          description:
            "Stratejik planlama ve organizasyonel gelişim konularında uzmanlığa sahip sektör deneyimli uzmanı.",
        },
      ],
    },
    stats: {
      title: "Etkimiz",
      items: [
        { number: "500+", label: "Mutlu Müşteri" },
        { number: "1000+", label: "Başarılı Proje" },
        { number: "15+", label: "Yıl Deneyim" },
        { number: "95%", label: "Müşteri Memnuniyeti" },
      ],
    },
    cta: {
      title: "İşinizi Dönüştürmeye Hazır mısınız?",
      subtitle: "Hedeflerinize nasıl ulaşabileceğinizi konuşalım",
      button: "Hemen Başlayın",
    },
  },
}

export default function AboutPage() {
  const { language } = useLanguage()
  const t = translations[language]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-navy-900 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t.hero.title}</h1>
          <p className="text-xl text-gray-300">{t.hero.subtitle}</p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-8 text-center">{t.story.title}</h2>
          <div className="space-y-6">
            {t.story.content.map((paragraph, index) => (
              <p key={index} className="text-lg text-gray-600 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 bg-navy-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-8">{t.mission.title}</h2>
          <p className="text-xl text-gray-600 leading-relaxed">{t.mission.content}</p>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-16 text-center">{t.values.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {t.values.items.map((value, index) => (
              <Card key={index} className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle className="h-6 w-6 text-navy-600" />
                  </div>
                  <CardTitle className="text-xl font-bold text-navy-900">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-navy-900 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">{t.stats.title}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {t.stats.items.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold mb-2 text-white">{stat.number}</div>
                <div className="text-gray-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-16 text-center">{t.team.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.team.members.map((member, index) => (
              <Card
                key={index}
                className="shadow-lg border-0 text-center hover:shadow-xl transition-shadow duration-300"
              >
                <CardHeader>
                  <div className="w-20 h-20 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-10 w-10 text-navy-600" />
                  </div>
                  <CardTitle className="text-lg font-bold text-navy-900">{member.name}</CardTitle>
                  <p className="text-navy-600 font-medium">{member.role}</p>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">{t.cta.title}</h2>
          <p className="text-xl text-gray-600 mb-8">{t.cta.subtitle}</p>
          <Link href="/contact">
            <Button size="lg" className="bg-navy-600 hover:bg-navy-700 px-8 py-3">
              {t.cta.button}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
