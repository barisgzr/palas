"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/contexts/language-context"
import { TrendingUp, CheckCircle, ArrowRight, Mail, Phone } from "lucide-react"
import { useState } from "react"

const translations = {
  en: {
    title: "Growth Acceleration Package",
    subtitle: "Market expansion strategies and growth initiatives to scale your business",
    overview: {
      title: "Package Overview",
      description:
        "Our Growth Acceleration package is designed for businesses ready to scale. We provide comprehensive market expansion strategies, growth planning, and implementation support to help you achieve sustainable, rapid growth while maintaining operational excellence.",
    },
    whatIncluded: {
      title: "What's Included",
      items: [
        "Market opportunity analysis and sizing",
        "Competitive landscape assessment",
        "Growth strategy development and roadmap",
        "Market entry and expansion planning",
        "Revenue model optimization",
        "Scaling operations framework",
        "Performance tracking and analytics",
        "Go-to-market strategy execution",
      ],
    },
    process: {
      title: "Our Process",
      steps: [
        {
          title: "Growth Assessment",
          description: "Evaluate current position and growth potential",
          duration: "2-3 weeks",
        },
        {
          title: "Strategy Development",
          description: "Create comprehensive growth strategy and roadmap",
          duration: "3-4 weeks",
        },
        {
          title: "Implementation Planning",
          description: "Detailed execution plans and resource allocation",
          duration: "2-3 weeks",
        },
        {
          title: "Execution Support",
          description: "Ongoing support during growth implementation",
          duration: "6+ months",
        },
      ],
    },
    benefits: {
      title: "Key Benefits",
      items: [
        "Accelerated revenue growth",
        "Market expansion opportunities",
        "Scalable business operations",
        "Competitive advantage",
        "Risk-managed growth",
        "Sustainable scaling framework",
      ],
    },
    pricing: {
      title: "Investment",
      price: "$18,000 - $30,000",
      description: "Final pricing depends on growth scope and market complexity",
      includes: "Includes all deliverables, workshops, and 8 months of growth support",
    },
    meeting: {
      title: "Request a Growth Strategy Consultation",
      subtitle: "Let's discuss how we can accelerate your business growth",
      name: "Full Name",
      email: "Email Address",
      company: "Company Name",
      employees: "Number of Employees",
      industry: "Industry",
      revenue: "Current Annual Revenue",
      markets: "Target Markets for Growth",
      challenges: "Growth Challenges",
      goals: "Growth Goals",
      timeline: "Preferred Timeline",
      send: "Request Consultation",
      success: "Thank you! We'll contact you within 24 hours to schedule your consultation.",
    },
  },
  tr: {
    title: "Büyüme Hızlandırma Paketi",
    subtitle: "İşinizi ölçeklendirmek için pazar genişleme stratejileri ve büyüme girişimleri",
    overview: {
      title: "Paket Genel Bakış",
      description:
        "Büyüme Hızlandırma paketimiz ölçeklenmeye hazır işletmeler için tasarlanmıştır. Operasyonel mükemmelliği korurken sürdürülebilir, hızlı büyüme elde etmenize yardımcı olmak için kapsamlı pazar genişleme stratejileri, büyüme planlaması ve uygulama desteği sağlarız.",
    },
    whatIncluded: {
      title: "Paket İçeriği",
      items: [
        "Pazar fırsatı analizi ve boyutlandırma",
        "Rekabet ortamı değerlendirmesi",
        "Büyüme stratejisi geliştirme ve yol haritası",
        "Pazara giriş ve genişleme planlaması",
        "Gelir modeli optimizasyonu",
        "Operasyon ölçeklendirme çerçevesi",
        "Performans takibi ve analitik",
        "Pazara çıkış stratejisi uygulaması",
      ],
    },
    process: {
      title: "Sürecimiz",
      steps: [
        {
          title: "Büyüme Değerlendirmesi",
          description: "Mevcut konumu ve büyüme potansiyelini değerlendirme",
          duration: "2-3 hafta",
        },
        {
          title: "Strateji Geliştirme",
          description: "Kapsamlı büyüme stratejisi ve yol haritası oluşturma",
          duration: "3-4 hafta",
        },
        {
          title: "Uygulama Planlaması",
          description: "Detaylı uygulama planları ve kaynak tahsisi",
          duration: "2-3 hafta",
        },
        {
          title: "Uygulama Desteği",
          description: "Büyüme uygulaması sırasında sürekli destek",
          duration: "6+ ay",
        },
      ],
    },
    benefits: {
      title: "Temel Faydalar",
      items: [
        "Hızlandırılmış gelir büyümesi",
        "Pazar genişleme fırsatları",
        "Ölçeklenebilir iş operasyonları",
        "Rekabet avantajı",
        "Risk yönetimli büyüme",
        "Sürdürülebilir ölçeklendirme çerçevesi",
      ],
    },
    pricing: {
      title: "Yatırım",
      price: "$18,000 - $30,000",
      description: "Nihai fiyatlandırma büyüme kapsamı ve pazar karmaşıklığına bağlıdır",
      includes: "Tüm çıktılar, atölyeler ve 8 aylık büyüme desteği dahildir",
    },
    meeting: {
      title: "Büyüme Stratejisi Danışmanlığı Talep Edin",
      subtitle: "İş büyümenizi nasıl hızlandırabileceğimizi konuşalım",
      name: "Ad Soyad",
      email: "E-posta Adresi",
      company: "Şirket Adı",
      employees: "Çalışan Sayısı",
      industry: "Sektör",
      revenue: "Mevcut Yıllık Gelir",
      markets: "Büyüme için Hedef Pazarlar",
      challenges: "Büyüme Zorlukları",
      goals: "Büyüme Hedefleri",
      timeline: "Tercih Edilen Zaman Çizelgesi",
      send: "Danışmanlık Talep Et",
      success: "Teşekkürler! Danışmanlığınızı planlamak için 24 saat içinde sizinle iletişime geçeceğiz.",
    },
  },
}

export default function GrowthAccelerationPage() {
  const { language } = useLanguage()
  const t = translations[language]
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    employees: "",
    industry: "",
    revenue: "",
    markets: "",
    challenges: "",
    goals: "",
    timeline: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Meeting request submitted:", formData)
    setIsSubmitted(true)
    setFormData({
      name: "",
      email: "",
      company: "",
      employees: "",
      industry: "",
      revenue: "",
      markets: "",
      challenges: "",
      goals: "",
      timeline: "",
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="w-20 h-20 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <TrendingUp className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-navy-900 mb-4">{t.title}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.overview.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">{t.overview.description}</p>
              </CardContent>
            </Card>

            {/* What's Included */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.whatIncluded.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {t.whatIncluded.items.map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Process */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.process.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {t.process.steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-navy-900 mb-1">{step.title}</h4>
                        <p className="text-gray-600 mb-2">{step.description}</p>
                        <span className="text-sm text-purple-600 font-medium">{step.duration}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.benefits.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {t.benefits.items.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-600">{benefit}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pricing */}
            <Card className="shadow-lg border-0 bg-purple-50">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-navy-900">{t.pricing.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-purple-600">{t.pricing.price}</div>
                <p className="text-sm text-gray-600">{t.pricing.description}</p>
                <div className="pt-4 border-t border-purple-200">
                  <p className="text-sm text-gray-600">{t.pricing.includes}</p>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  <a href="#request-meeting">Request Consultation</a>
                </Button>
              </CardContent>
            </Card>

            {/* Quick Contact */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-navy-900">Quick Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-navy-600" />
                  <span className="text-gray-600">info@consultpro.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-navy-600" />
                  <span className="text-gray-600">+1 (555) 123-4567</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Meeting Request Form */}
        <Card id="request-meeting" className="shadow-xl border-0 bg-white">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-navy-900">{t.meeting.title}</CardTitle>
            <CardDescription className="text-lg text-gray-600">{t.meeting.subtitle}</CardDescription>
          </CardHeader>
          <CardContent className="max-w-2xl mx-auto">
            {isSubmitted ? (
              <div className="text-center py-8">
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg text-gray-600">{t.meeting.success}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Input
                      name="name"
                      placeholder={t.meeting.name}
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="email"
                      type="email"
                      placeholder={t.meeting.email}
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="company"
                      placeholder={t.meeting.company}
                      value={formData.company}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <select
                      name="employees"
                      value={formData.employees}
                      onChange={handleInputChange}
                      required
                      className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">{t.meeting.employees}</option>
                      <option value="1-10">1-10</option>
                      <option value="11-50">11-50</option>
                      <option value="51-200">51-200</option>
                      <option value="201-1000">201-1000</option>
                      <option value="1000+">1000+</option>
                    </select>
                  </div>
                  <div>
                    <Input
                      name="industry"
                      placeholder={t.meeting.industry}
                      value={formData.industry}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <select
                      name="revenue"
                      value={formData.revenue}
                      onChange={handleInputChange}
                      required
                      className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">{t.meeting.revenue}</option>
                      <option value="under-100k">Under $100K</option>
                      <option value="100k-500k">$100K - $500K</option>
                      <option value="500k-1m">$500K - $1M</option>
                      <option value="1m-5m">$1M - $5M</option>
                      <option value="5m-10m">$5M - $10M</option>
                      <option value="over-10m">Over $10M</option>
                    </select>
                  </div>
                  <div>
                    <select
                      name="timeline"
                      value={formData.timeline}
                      onChange={handleInputChange}
                      required
                      className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">{t.meeting.timeline}</option>
                      <option value="immediate">Immediate (1-2 weeks)</option>
                      <option value="short">Short term (1-2 months)</option>
                      <option value="medium">Medium term (3-6 months)</option>
                      <option value="long">Long term (6+ months)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Textarea
                    name="markets"
                    placeholder={t.meeting.markets}
                    value={formData.markets}
                    onChange={handleInputChange}
                    required
                    rows={3}
                  />
                </div>
                <div>
                  <Textarea
                    name="challenges"
                    placeholder={t.meeting.challenges}
                    value={formData.challenges}
                    onChange={handleInputChange}
                    required
                    rows={3}
                  />
                </div>
                <div>
                  <Textarea
                    name="goals"
                    placeholder={t.meeting.goals}
                    value={formData.goals}
                    onChange={handleInputChange}
                    required
                    rows={3}
                  />
                </div>
                <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 h-12 text-lg">
                  {t.meeting.send}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
