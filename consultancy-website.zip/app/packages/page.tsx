"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/contexts/language-context"
import { ArrowRight, Target, CheckCircle, TrendingUp, Clock, Users, Award } from "lucide-react"
import Link from "next/link"

const translations = {
  en: {
    title: "Our Service Packages",
    subtitle: "Comprehensive consultancy solutions tailored to your business needs",
    strategic: {
      title: "Strategic Planning",
      description: "Comprehensive business strategy development and implementation guidance for long-term success.",
      features: ["Market Analysis", "Strategic Roadmap", "Implementation Plan", "Performance Metrics"],
      duration: "3-6 months",
      team: "Senior Consultants",
      price: "Starting from $15,000",
    },
    operational: {
      title: "Operational Excellence",
      description: "Process optimization and efficiency improvements to maximize your business performance.",
      features: ["Process Mapping", "Efficiency Analysis", "Workflow Optimization", "Quality Systems"],
      duration: "2-4 months",
      team: "Operations Experts",
      price: "Starting from $12,000",
    },
    growth: {
      title: "Growth Acceleration",
      description: "Market expansion strategies and growth initiatives to scale your business effectively.",
      features: ["Market Research", "Growth Strategy", "Scaling Plans", "Performance Tracking"],
      duration: "4-8 months",
      team: "Growth Specialists",
      price: "Starting from $18,000",
    },
    features: "Key Features",
    duration: "Duration",
    team: "Team",
    pricing: "Pricing",
    learnMore: "Learn More",
    requestMeeting: "Request Meeting",
  },
  tr: {
    title: "Hizmet Paketlerimiz",
    subtitle: "İş ihtiyaçlarınıza özel kapsamlı danışmanlık çözümleri",
    strategic: {
      title: "Stratejik Planlama",
      description: "Uzun vadeli başarı için kapsamlı iş stratejisi geliştirme ve uygulama rehberliği.",
      features: ["Pazar Analizi", "Stratejik Yol Haritası", "Uygulama Planı", "Performans Metrikleri"],
      duration: "3-6 ay",
      team: "Kıdemli Danışmanlar",
      price: "15.000$'dan başlayan fiyatlar",
    },
    operational: {
      title: "Operasyonel Mükemmellik",
      description: "İş performansınızı maksimize etmek için süreç optimizasyonu ve verimlilik iyileştirmeleri.",
      features: ["Süreç Haritalama", "Verimlilik Analizi", "İş Akışı Optimizasyonu", "Kalite Sistemleri"],
      duration: "2-4 ay",
      team: "Operasyon Uzmanları",
      price: "12.000$'dan başlayan fiyatlar",
    },
    growth: {
      title: "Büyüme Hızlandırma",
      description: "İşinizi etkili bir şekilde ölçeklendirmek için pazar genişleme stratejileri ve büyüme girişimleri.",
      features: ["Pazar Araştırması", "Büyüme Stratejisi", "Ölçeklendirme Planları", "Performans Takibi"],
      duration: "4-8 ay",
      team: "Büyüme Uzmanları",
      price: "18.000$'dan başlayan fiyatlar",
    },
    features: "Temel Özellikler",
    duration: "Süre",
    team: "Ekip",
    pricing: "Fiyatlandırma",
    learnMore: "Daha Fazla Bilgi",
    requestMeeting: "Toplantı Talep Et",
  },
}

export default function PackagesPage() {
  const { language } = useLanguage()
  const t = translations[language]

  const packages = [
    {
      id: "strategic-planning",
      icon: Target,
      title: t.strategic.title,
      description: t.strategic.description,
      features: t.strategic.features,
      duration: t.strategic.duration,
      team: t.strategic.team,
      price: t.strategic.price,
      color: "bg-blue-500",
    },
    {
      id: "operational-excellence",
      icon: CheckCircle,
      title: t.operational.title,
      description: t.operational.description,
      features: t.operational.features,
      duration: t.operational.duration,
      team: t.operational.team,
      price: t.operational.price,
      color: "bg-green-500",
    },
    {
      id: "growth-acceleration",
      icon: TrendingUp,
      title: t.growth.title,
      description: t.growth.description,
      features: t.growth.features,
      duration: t.growth.duration,
      team: t.growth.team,
      price: t.growth.price,
      color: "bg-purple-500",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-navy-900 mb-6">{t.title}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => {
            const IconComponent = pkg.icon
            return (
              <Card key={pkg.id} className="hover:shadow-xl transition-shadow duration-300 border-0 shadow-lg">
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 ${pkg.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-navy-900">{pkg.title}</CardTitle>
                  <CardDescription className="text-gray-600 leading-relaxed">{pkg.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Features */}
                  <div>
                    <h4 className="font-semibold text-navy-900 mb-3">{t.features}</h4>
                    <ul className="space-y-2">
                      {pkg.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2 text-gray-600">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Package Details */}
                  <div className="space-y-3 pt-4 border-t">
                    <div className="flex items-center gap-3">
                      <Clock className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="font-medium text-navy-900">{t.duration}:</span>
                        <span className="text-gray-600 ml-2">{pkg.duration}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Users className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="font-medium text-navy-900">{t.team}:</span>
                        <span className="text-gray-600 ml-2">{pkg.team}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Award className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="font-medium text-navy-900">{t.pricing}:</span>
                        <span className="text-gray-600 ml-2">{pkg.price}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-3 pt-4">
                    <Link href={`/packages/${pkg.id}`}>
                      <Button className="w-full bg-navy-600 hover:bg-navy-700">
                        {t.learnMore}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                    <Link href={`/packages/${pkg.id}#request-meeting`}>
                      <Button
                        variant="outline"
                        className="w-full border-navy-600 text-navy-600 hover:bg-navy-600 hover:text-white bg-transparent"
                      >
                        {t.requestMeeting}
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}
