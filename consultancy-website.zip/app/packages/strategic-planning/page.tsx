"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/contexts/language-context"
import { Target, CheckCircle, ArrowRight, Mail, Phone } from "lucide-react"
import { useState } from "react"

const translations = {
  en: {
    title: "Strategic Planning Package",
    subtitle: "Comprehensive business strategy development for long-term success",
    overview: {
      title: "Package Overview",
      description:
        "Our Strategic Planning package provides comprehensive business strategy development and implementation guidance. We work closely with your leadership team to create a roadmap for sustainable growth and competitive advantage.",
    },
    whatIncluded: {
      title: "What's Included",
      items: [
        "Comprehensive market and competitive analysis",
        "SWOT analysis and strategic positioning",
        "3-5 year strategic roadmap development",
        "Implementation planning and milestones",
        "Performance metrics and KPI framework",
        "Quarterly review sessions",
        "Strategic communication plan",
        "Risk assessment and mitigation strategies",
      ],
    },
    process: {
      title: "Our Process",
      steps: [
        {
          title: "Discovery & Analysis",
          description: "Deep dive into your business, market, and competitive landscape",
          duration: "2-3 weeks",
        },
        {
          title: "Strategy Development",
          description: "Collaborative strategy formulation with your leadership team",
          duration: "3-4 weeks",
        },
        {
          title: "Implementation Planning",
          description: "Detailed action plans and resource allocation",
          duration: "2-3 weeks",
        },
        {
          title: "Launch & Support",
          description: "Strategy rollout and ongoing support",
          duration: "Ongoing",
        },
      ],
    },
    benefits: {
      title: "Key Benefits",
      items: [
        "Clear strategic direction and focus",
        "Improved decision-making framework",
        "Enhanced competitive positioning",
        "Aligned organizational goals",
        "Measurable performance improvements",
        "Risk mitigation strategies",
      ],
    },
    pricing: {
      title: "Investment",
      price: "$15,000 - $25,000",
      description: "Final pricing depends on company size and complexity",
      includes: "Includes all deliverables, workshops, and 6 months of implementation support",
    },
    meeting: {
      title: "Request a Strategy Consultation",
      subtitle: "Let's discuss how strategic planning can transform your business",
      name: "Full Name",
      email: "Email Address",
      company: "Company Name",
      employees: "Number of Employees",
      industry: "Industry",
      challenges: "Current Business Challenges",
      goals: "Strategic Goals",
      timeline: "Preferred Timeline",
      send: "Request Consultation",
      success: "Thank you! We'll contact you within 24 hours to schedule your consultation.",
    },
  },
  tr: {
    title: "Stratejik Planlama Paketi",
    subtitle: "Uzun vadeli başarı için kapsamlı iş stratejisi geliştirme",
    overview: {
      title: "Paket Genel Bakış",
      description:
        "Stratejik Planlama paketimiz kapsamlı iş stratejisi geliştirme ve uygulama rehberliği sağlar. Sürdürülebilir büyüme ve rekabet avantajı için bir yol haritası oluşturmak üzere liderlik ekibinizle yakın çalışırız.",
    },
    whatIncluded: {
      title: "Paket İçeriği",
      items: [
        "Kapsamlı pazar ve rekabet analizi",
        "SWOT analizi ve stratejik konumlandırma",
        "3-5 yıllık stratejik yol haritası geliştirme",
        "Uygulama planlaması ve kilometre taşları",
        "Performans metrikleri ve KPI çerçevesi",
        "Üç aylık gözden geçirme oturumları",
        "Stratejik iletişim planı",
        "Risk değerlendirmesi ve azaltma stratejileri",
      ],
    },
    process: {
      title: "Sürecimiz",
      steps: [
        {
          title: "Keşif ve Analiz",
          description: "İşiniz, pazarınız ve rekabet ortamınız hakkında derinlemesine inceleme",
          duration: "2-3 hafta",
        },
        {
          title: "Strateji Geliştirme",
          description: "Liderlik ekibinizle işbirlikçi strateji oluşturma",
          duration: "3-4 hafta",
        },
        {
          title: "Uygulama Planlaması",
          description: "Detaylı eylem planları ve kaynak tahsisi",
          duration: "2-3 hafta",
        },
        {
          title: "Başlatma ve Destek",
          description: "Strateji lansmanı ve sürekli destek",
          duration: "Devam eden",
        },
      ],
    },
    benefits: {
      title: "Temel Faydalar",
      items: [
        "Net stratejik yön ve odak",
        "Gelişmiş karar verme çerçevesi",
        "Güçlendirilmiş rekabet konumu",
        "Uyumlu organizasyonel hedefler",
        "Ölçülebilir performans iyileştirmeleri",
        "Risk azaltma stratejileri",
      ],
    },
    pricing: {
      title: "Yatırım",
      price: "$15,000 - $25,000",
      description: "Nihai fiyatlandırma şirket büyüklüğü ve karmaşıklığına bağlıdır",
      includes: "Tüm çıktılar, atölyeler ve 6 aylık uygulama desteği dahildir",
    },
    meeting: {
      title: "Strateji Danışmanlığı Talep Edin",
      subtitle: "Stratejik planlamanın işinizi nasıl dönüştürebileceğini konuşalım",
      name: "Ad Soyad",
      email: "E-posta Adresi",
      company: "Şirket Adı",
      employees: "Çalışan Sayısı",
      industry: "Sektör",
      challenges: "Mevcut İş Zorlukları",
      goals: "Stratejik Hedefler",
      timeline: "Tercih Edilen Zaman Çizelgesi",
      send: "Danışmanlık Talep Et",
      success: "Teşekkürler! Danışmanlığınızı planlamak için 24 saat içinde sizinle iletişime geçeceğiz.",
    },
  },
}

export default function StrategicPlanningPage() {
  const { language } = useLanguage()
  const t = translations[language]
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    employees: "",
    industry: "",
    challenges: "",
    goals: "",
    timeline: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the form data to your email service
    console.log("Meeting request submitted:", formData)
    setIsSubmitted(true)
    setFormData({
      name: "",
      email: "",
      company: "",
      employees: "",
      industry: "",
      challenges: "",
      goals: "",
      timeline: "",
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Target className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-navy-900 mb-4">{t.title}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">{t.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.overview.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">{t.overview.description}</p>
              </CardContent>
            </Card>

            {/* What's Included */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.whatIncluded.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {t.whatIncluded.items.map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Process */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.process.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {t.process.steps.map((step, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-navy-900 mb-1">{step.title}</h4>
                        <p className="text-gray-600 mb-2">{step.description}</p>
                        <span className="text-sm text-blue-600 font-medium">{step.duration}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">{t.benefits.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {t.benefits.items.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-600">{benefit}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pricing */}
            <Card className="shadow-lg border-0 bg-navy-50">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-navy-900">{t.pricing.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-navy-600">{t.pricing.price}</div>
                <p className="text-sm text-gray-600">{t.pricing.description}</p>
                <div className="pt-4 border-t border-navy-200">
                  <p className="text-sm text-gray-600">{t.pricing.includes}</p>
                </div>
                <Button className="w-full bg-navy-600 hover:bg-navy-700">
                  <a href="#request-meeting">Request Consultation</a>
                </Button>
              </CardContent>
            </Card>

            {/* Quick Contact */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-navy-900">Quick Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-navy-600" />
                  <span className="text-gray-600">info@consultpro.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-navy-600" />
                  <span className="text-gray-600">+1 (555) 123-4567</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Meeting Request Form */}
        <Card id="request-meeting" className="shadow-xl border-0 bg-white">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-navy-900">{t.meeting.title}</CardTitle>
            <CardDescription className="text-lg text-gray-600">{t.meeting.subtitle}</CardDescription>
          </CardHeader>
          <CardContent className="max-w-2xl mx-auto">
            {isSubmitted ? (
              <div className="text-center py-8">
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg text-gray-600">{t.meeting.success}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Input
                      name="name"
                      placeholder={t.meeting.name}
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="email"
                      type="email"
                      placeholder={t.meeting.email}
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="company"
                      placeholder={t.meeting.company}
                      value={formData.company}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <select
                      name="employees"
                      value={formData.employees}
                      onChange={handleInputChange}
                      required
                      className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-navy-500"
                    >
                      <option value="">{t.meeting.employees}</option>
                      <option value="1-10">1-10</option>
                      <option value="11-50">11-50</option>
                      <option value="51-200">51-200</option>
                      <option value="201-1000">201-1000</option>
                      <option value="1000+">1000+</option>
                    </select>
                  </div>
                  <div>
                    <Input
                      name="industry"
                      placeholder={t.meeting.industry}
                      value={formData.industry}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <select
                      name="timeline"
                      value={formData.timeline}
                      onChange={handleInputChange}
                      required
                      className="w-full h-12 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-navy-500"
                    >
                      <option value="">{t.meeting.timeline}</option>
                      <option value="immediate">Immediate (1-2 weeks)</option>
                      <option value="short">Short term (1-2 months)</option>
                      <option value="medium">Medium term (3-6 months)</option>
                      <option value="long">Long term (6+ months)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Textarea
                    name="challenges"
                    placeholder={t.meeting.challenges}
                    value={formData.challenges}
                    onChange={handleInputChange}
                    required
                    rows={3}
                  />
                </div>
                <div>
                  <Textarea
                    name="goals"
                    placeholder={t.meeting.goals}
                    value={formData.goals}
                    onChange={handleInputChange}
                    required
                    rows={3}
                  />
                </div>
                <Button type="submit" className="w-full bg-navy-600 hover:bg-navy-700 h-12 text-lg">
                  {t.meeting.send}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
