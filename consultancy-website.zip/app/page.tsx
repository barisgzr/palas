"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/contexts/language-context"
import { ArrowRight, CheckCircle, TrendingUp, Target, Mail, Phone, MapPin } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

const translations = {
  en: {
    hero: {
      title: "Transform Your Business with Expert Consultancy",
      subtitle: "Professional guidance to help your business reach new heights of success",
      cta: "Get Started Today",
      learnMore: "Learn More",
    },
    about: {
      title: "About ConsultPro",
      description:
        "With over 15 years of experience in business consultancy, we help companies of all sizes achieve their goals through strategic planning, operational excellence, and innovative solutions. Our team of experts is dedicated to delivering measurable results that drive sustainable growth.",
      experience: "15+ Years Experience",
      clients: "500+ Happy Clients",
      projects: "1000+ Successful Projects",
    },
    services: {
      title: "Our Service Packages",
      subtitle: "Choose the perfect package for your business needs",
      strategic: {
        title: "Strategic Planning",
        description: "Comprehensive business strategy development and implementation guidance for long-term success.",
      },
      operational: {
        title: "Operational Excellence",
        description: "Process optimization and efficiency improvements to maximize your business performance.",
      },
      growth: {
        title: "Growth Acceleration",
        description: "Market expansion strategies and growth initiatives to scale your business effectively.",
      },
      viewDetails: "View Details",
    },
    contact: {
      title: "Ready to Get Started?",
      subtitle: "Contact us today for a free consultation",
      name: "Full Name",
      email: "Email Address",
      company: "Company Name",
      message: "Message",
      send: "Send Message",
      or: "or",
      contactUs: "Contact Us Directly",
    },
  },
  tr: {
    hero: {
      title: "Uzman Danışmanlık ile İşinizi Dönüştürün",
      subtitle: "İşinizin yeni başarı zirvelerine ulaşması için profesyonel rehberlik",
      cta: "Hemen Başlayın",
      learnMore: "Daha Fazla Bilgi",
    },
    about: {
      title: "ConsultPro Hakkında",
      description:
        "15 yılı aşkın iş danışmanlığı deneyimimizle, her büyüklükteki şirketin stratejik planlama, operasyonel mükemmellik ve yenilikçi çözümler aracılığıyla hedeflerine ulaşmasına yardımcı oluyoruz. Uzman ekibimiz, sürdürülebilir büyümeyi sağlayan ölçülebilir sonuçlar sunmaya odaklanmıştır.",
      experience: "15+ Yıl Deneyim",
      clients: "500+ Mutlu Müşteri",
      projects: "1000+ Başarılı Proje",
    },
    services: {
      title: "Hizmet Paketlerimiz",
      subtitle: "İşinizin ihtiyaçları için mükemmel paketi seçin",
      strategic: {
        title: "Stratejik Planlama",
        description: "Uzun vadeli başarı için kapsamlı iş stratejisi geliştirme ve uygulama rehberliği.",
      },
      operational: {
        title: "Operasyonel Mükemmellik",
        description: "İş performansınızı maksimize etmek için süreç optimizasyonu ve verimlilik iyileştirmeleri.",
      },
      growth: {
        title: "Büyüme Hızlandırma",
        description:
          "İşinizi etkili bir şekilde ölçeklendirmek için pazar genişleme stratejileri ve büyüme girişimleri.",
      },
      viewDetails: "Detayları Görüntüle",
    },
    contact: {
      title: "Başlamaya Hazır mısınız?",
      subtitle: "Ücretsiz danışmanlık için bugün bize ulaşın",
      name: "Ad Soyad",
      email: "E-posta Adresi",
      company: "Şirket Adı",
      message: "Mesaj",
      send: "Mesaj Gönder",
      or: "veya",
      contactUs: "Doğrudan İletişime Geçin",
    },
  },
}

export default function HomePage() {
  const { language } = useLanguage()
  const t = translations[language]
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the form data to your email service
    console.log("Form submitted:", formData)
    alert("Thank you for your message! We'll get back to you soon.")
    setFormData({ name: "", email: "", company: "", message: "" })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section
        className="relative h-screen flex items-center justify-center text-white"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('/professional-sunrise-consultancy.png')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">{t.hero.title}</h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">{t.hero.subtitle}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-navy-600 hover:bg-navy-700 text-white px-8 py-3">
              {t.hero.cta}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-navy-900 px-8 py-3 bg-transparent"
            >
              {t.hero.learnMore}
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">{t.about.title}</h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">{t.about.description}</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-navy-600 mb-2">{t.about.experience}</div>
                  <div className="text-gray-600">Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-navy-600 mb-2">{t.about.clients}</div>
                  <div className="text-gray-600">Happy Clients</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-navy-600 mb-2">{t.about.projects}</div>
                  <div className="text-gray-600">Successful Projects</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholder-rv2jv.png"
                alt="Professional consultancy meeting"
                className="rounded-lg shadow-xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">{t.services.title}</h2>
            <p className="text-xl text-gray-600">{t.services.subtitle}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Strategic Planning */}
            <Card className="hover:shadow-lg transition-shadow duration-300 border-0 shadow-md">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8 text-navy-600" />
                </div>
                <CardTitle className="text-xl font-bold text-navy-900">{t.services.strategic.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6 leading-relaxed">
                  {t.services.strategic.description}
                </CardDescription>
                <Link href="/packages/strategic-planning">
                  <Button
                    variant="outline"
                    className="w-full border-navy-600 text-navy-600 hover:bg-navy-600 hover:text-white bg-transparent"
                  >
                    {t.services.viewDetails}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Operational Excellence */}
            <Card className="hover:shadow-lg transition-shadow duration-300 border-0 shadow-md">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-navy-600" />
                </div>
                <CardTitle className="text-xl font-bold text-navy-900">{t.services.operational.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6 leading-relaxed">
                  {t.services.operational.description}
                </CardDescription>
                <Link href="/packages/operational-excellence">
                  <Button
                    variant="outline"
                    className="w-full border-navy-600 text-navy-600 hover:bg-navy-600 hover:text-white bg-transparent"
                  >
                    {t.services.viewDetails}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Growth Acceleration */}
            <Card className="hover:shadow-lg transition-shadow duration-300 border-0 shadow-md">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8 text-navy-600" />
                </div>
                <CardTitle className="text-xl font-bold text-navy-900">{t.services.growth.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6 leading-relaxed">
                  {t.services.growth.description}
                </CardDescription>
                <Link href="/packages/growth-acceleration">
                  <Button
                    variant="outline"
                    className="w-full border-navy-600 text-navy-600 hover:bg-navy-600 hover:text-white bg-transparent"
                  >
                    {t.services.viewDetails}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">{t.contact.title}</h2>
            <p className="text-xl text-gray-600">{t.contact.subtitle}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-navy-900">Send us a message</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Input
                      name="name"
                      placeholder={t.contact.name}
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="email"
                      type="email"
                      placeholder={t.contact.email}
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Input
                      name="company"
                      placeholder={t.contact.company}
                      value={formData.company}
                      onChange={handleInputChange}
                      className="h-12"
                    />
                  </div>
                  <div>
                    <Textarea
                      name="message"
                      placeholder={t.contact.message}
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={4}
                    />
                  </div>
                  <Button type="submit" className="w-full bg-navy-600 hover:bg-navy-700 h-12">
                    {t.contact.send}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="flex flex-col justify-center">
              <div className="text-center mb-8">
                <p className="text-lg text-gray-600 mb-6">{t.contact.or}</p>
                <Link href="/contact">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-navy-600 text-navy-600 hover:bg-navy-600 hover:text-white bg-transparent"
                  >
                    {t.contact.contactUs}
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center">
                    <Mail className="h-6 w-6 text-navy-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-navy-900">Email</div>
                    <div className="text-gray-600">info@consultpro.com</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center">
                    <Phone className="h-6 w-6 text-navy-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-navy-900">Phone</div>
                    <div className="text-gray-600">+1 (555) 123-4567</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-navy-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-navy-900">Address</div>
                    <div className="text-gray-600">123 Business Ave, City</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
