"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useLanguage } from "@/contexts/language-context"
import { HelpCircle, MessageCircle, Phone, Mail } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const translations = {
  en: {
    hero: {
      title: "Frequently Asked Questions",
      subtitle: "Find answers to common questions about our consultancy services",
    },
    general: {
      title: "General Questions",
      items: [
        {
          question: "What types of businesses do you work with?",
          answer:
            "We work with businesses of all sizes, from startups to large enterprises, across various industries including technology, healthcare, manufacturing, retail, and professional services. Our consultancy approach is tailored to each client's specific needs and industry requirements.",
        },
        {
          question: "How long does a typical consultancy project take?",
          answer:
            "Project duration varies depending on the scope and complexity. Strategic Planning projects typically take 3-6 months, Operational Excellence projects take 2-4 months, and Growth Acceleration projects can take 4-8 months. We provide detailed timelines during our initial consultation.",
        },
        {
          question: "Do you offer remote consultancy services?",
          answer:
            "Yes, we offer both remote and on-site consultancy services. Many of our projects can be conducted remotely through video conferences, collaborative tools, and digital workshops. For projects requiring on-site presence, we travel to client locations as needed.",
        },
        {
          question: "What makes ConsultPro different from other consultancy firms?",
          answer:
            "Our approach combines deep industry expertise with practical, results-driven solutions. We focus on implementation support, not just recommendations. Our team has hands-on experience in the challenges we help solve, and we maintain long-term relationships with our clients.",
        },
      ],
    },
    services: {
      title: "Service-Related Questions",
      items: [
        {
          question: "Can I customize a package to fit my specific needs?",
          answer:
            "While we offer three main packages, we understand that every business is unique. We can customize our services to address your specific challenges and goals. Contact us to discuss your requirements and we'll create a tailored solution.",
        },
        {
          question: "Do you provide ongoing support after project completion?",
          answer:
            "Yes, all our packages include post-project support. Strategic Planning includes 6 months of implementation support, Operational Excellence includes 4 months, and Growth Acceleration includes 8 months. We also offer extended support contracts if needed.",
        },
        {
          question: "What deliverables can I expect from your services?",
          answer:
            "Deliverables vary by package but typically include comprehensive reports, strategic roadmaps, implementation plans, process documentation, training materials, and performance metrics frameworks. All deliverables are customized to your business needs.",
        },
        {
          question: "How do you measure the success of your consultancy projects?",
          answer:
            "We establish clear KPIs and success metrics at the beginning of each project. These may include revenue growth, cost reduction, efficiency improvements, customer satisfaction scores, or other relevant business metrics. We provide regular progress reports and final impact assessments.",
        },
      ],
    },
    pricing: {
      title: "Pricing & Process Questions",
      items: [
        {
          question: "How is your pricing structured?",
          answer:
            "Our pricing is project-based and depends on scope, complexity, and duration. We offer transparent pricing with no hidden fees. After our initial consultation, we provide a detailed proposal with fixed pricing for the agreed scope of work.",
        },
        {
          question: "Do you offer payment plans?",
          answer:
            "Yes, we offer flexible payment terms. Typically, we structure payments in milestones: 30% upon project initiation, 40% at mid-project milestone, and 30% upon completion. We can discuss alternative arrangements based on your needs.",
        },
        {
          question: "What happens during the initial consultation?",
          answer:
            "The initial consultation is a comprehensive discussion about your business challenges, goals, and current situation. We assess your needs, explain our approach, and determine if we're a good fit. This consultation is free and typically lasts 60-90 minutes.",
        },
        {
          question: "How quickly can you start a project?",
          answer:
            "We can typically begin projects within 1-2 weeks of contract signing, depending on our current capacity and your requirements. For urgent projects, we may be able to start sooner. We'll provide a clear start date during our proposal discussion.",
        },
      ],
    },
    contact: {
      title: "Still Have Questions?",
      subtitle: "We're here to help! Contact us for personalized answers to your specific questions.",
      phone: "Call us at +1 (555) 123-4567",
      email: "Email us at info@consultpro.com",
      meeting: "Schedule a Free Consultation",
    },
  },
  tr: {
    hero: {
      title: "Sıkça Sorulan Sorular",
      subtitle: "Danışmanlık hizmetlerimiz hakkında sık sorulan soruların cevaplarını bulun",
    },
    general: {
      title: "Genel Sorular",
      items: [
        {
          question: "Hangi tür işletmelerle çalışıyorsunuz?",
          answer:
            "Teknoloji, sağlık, üretim, perakende ve profesyonel hizmetler dahil olmak üzere çeşitli sektörlerde, startup'lardan büyük kuruluşlara kadar her büyüklükteki işletmeyle çalışıyoruz. Danışmanlık yaklaşımımız her müşterinin özel ihtiyaçlarına ve sektör gereksinimlerine göre uyarlanır.",
        },
        {
          question: "Tipik bir danışmanlık projesi ne kadar sürer?",
          answer:
            "Proje süresi kapsam ve karmaşıklığa bağlı olarak değişir. Stratejik Planlama projeleri genellikle 3-6 ay, Operasyonel Mükemmellik projeleri 2-4 ay ve Büyüme Hızlandırma projeleri 4-8 ay sürer. İlk danışmanlığımız sırasında detaylı zaman çizelgeleri sağlarız.",
        },
        {
          question: "Uzaktan danışmanlık hizmetleri sunuyor musunuz?",
          answer:
            "Evet, hem uzaktan hem de yerinde danışmanlık hizmetleri sunuyoruz. Projelerimizin çoğu video konferanslar, işbirliği araçları ve dijital atölyeler aracılığıyla uzaktan yürütülebilir. Yerinde bulunma gerektiren projeler için gerektiğinde müşteri lokasyonlarına seyahat ederiz.",
        },
        {
          question: "ConsultPro'yu diğer danışmanlık firmalarından ayıran nedir?",
          answer:
            "Yaklaşımımız derin sektör uzmanlığını pratik, sonuç odaklı çözümlerle birleştirir. Sadece öneriler değil, uygulama desteğine odaklanırız. Ekibimiz çözmeye yardımcı olduğumuz zorluklarda uygulamalı deneyime sahiptir ve müşterilerimizle uzun vadeli ilişkiler sürdürürüz.",
        },
      ],
    },
    services: {
      title: "Hizmet İlgili Sorular",
      items: [
        {
          question: "Bir paketi özel ihtiyaçlarıma göre özelleştirebilir miyim?",
          answer:
            "Kesinlikle! Üç ana paket sunmamıza rağmen, her işletmenin benzersiz olduğunu anlıyoruz. Hizmetlerimizi özel zorluklarınızı ve hedeflerinizi ele alacak şekilde özelleştirebiliriz. Gereksinimlerinizi görüşmek için bizimle iletişime geçin, size özel bir çözüm oluşturalım.",
        },
        {
          question: "Proje tamamlandıktan sonra sürekli destek sağlıyor musunuz?",
          answer:
            "Evet, tüm paketlerimiz proje sonrası destek içerir. Stratejik Planlama 6 aylık uygulama desteği, Operasyonel Mükemmellik 4 ay ve Büyüme Hızlandırma 8 aylık destek içerir. Gerekirse uzatılmış destek sözleşmeleri de sunuyoruz.",
        },
        {
          question: "Hizmetlerinizden hangi çıktıları bekleyebilirim?",
          answer:
            "Çıktılar pakete göre değişir ancak genellikle kapsamlı raporlar, stratejik yol haritaları, uygulama planları, süreç dokümantasyonu, eğitim materyalleri ve performans metrikleri çerçeveleri içerir. Tüm çıktılar işletme ihtiyaçlarınıza göre özelleştirilir.",
        },
        {
          question: "Danışmanlık projelerinizin başarısını nasıl ölçüyorsunuz?",
          answer:
            "Her projenin başında net KPI'lar ve başarı metrikleri belirliyoruz. Bunlar gelir artışı, maliyet azaltma, verimlilik iyileştirmeleri, müşteri memnuniyet puanları veya diğer ilgili iş metrikleri olabilir. Düzenli ilerleme raporları ve nihai etki değerlendirmeleri sağlarız.",
        },
      ],
    },
    pricing: {
      title: "Fiyatlandırma ve Süreç Soruları",
      items: [
        {
          question: "Fiyatlandırmanız nasıl yapılandırılmış?",
          answer:
            "Fiyatlandırmamız proje bazlıdır ve kapsam, karmaşıklık ve süreye bağlıdır. Gizli ücret olmayan şeffaf fiyatlandırma sunuyoruz. İlk danışmanlığımızdan sonra, üzerinde anlaşılan çalışma kapsamı için sabit fiyatlandırmalı detaylı bir teklif sağlarız.",
        },
        {
          question: "Ödeme planları sunuyor musunuz?",
          answer:
            "Evet, esnek ödeme koşulları sunuyoruz. Genellikle ödemeleri kilometre taşlarında yapılandırırız: proje başlangıcında %30, proje ortası kilometre taşında %40 ve tamamlanmasında %30. İhtiyaçlarınıza göre alternatif düzenlemeler görüşebiliriz.",
        },
        {
          question: "İlk danışmanlık sırasında ne olur?",
          answer:
            "İlk danışmanlık, iş zorluklarınız, hedefleriniz ve mevcut durumunuz hakkında kapsamlı bir görüşmedir. İhtiyaçlarınızı değerlendiriyor, yaklaşımımızı açıklıyor ve uyumlu olup olmadığımızı belirliyoruz. Bu danışmanlık ücretsizdir ve genellikle 60-90 dakika sürer.",
        },
        {
          question: "Bir projeye ne kadar hızlı başlayabilirsiniz?",
          answer:
            "Mevcut kapasitemize ve gereksinimlerinize bağlı olarak, genellikle sözleşme imzalandıktan sonra 1-2 hafta içinde projelere başlayabiliriz. Acil projeler için daha erken başlayabiliriz. Teklif görüşmemiz sırasında net bir başlangıç tarihi sağlarız.",
        },
      ],
    },
    contact: {
      title: "Hala Sorularınız Var mı?",
      subtitle:
        "Yardım etmek için buradayız! Özel sorularınıza kişiselleştirilmiş cevaplar için bizimle iletişime geçin.",
      phone: "Bizi +1 (555) 123-4567 numarasından arayın",
      email: "info@consultpro.com adresine e-posta gönderin",
      meeting: "Ücretsiz Danışmanlık Planlayın",
    },
  },
}

export default function FAQPage() {
  const { language } = useLanguage()
  const t = translations[language]

  const faqSections = [
    { title: t.general.title, items: t.general.items, icon: HelpCircle },
    { title: t.services.title, items: t.services.items, icon: MessageCircle },
    { title: t.pricing.title, items: t.pricing.items, icon: Phone },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-navy-900 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t.hero.title}</h1>
          <p className="text-xl text-gray-300">{t.hero.subtitle}</p>
        </div>
      </section>

      {/* FAQ Sections */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {faqSections.map((section, sectionIndex) => {
              const IconComponent = section.icon
              return (
                <Card key={sectionIndex} className="shadow-lg border-0">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center">
                        <IconComponent className="h-6 w-6 text-navy-600" />
                      </div>
                      <CardTitle className="text-2xl font-bold text-navy-900">{section.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Accordion type="single" collapsible className="space-y-4">
                      {section.items.map((item, itemIndex) => (
                        <AccordionItem
                          key={itemIndex}
                          value={`${sectionIndex}-${itemIndex}`}
                          className="border border-gray-200 rounded-lg px-4"
                        >
                          <AccordionTrigger className="text-left font-semibold text-navy-900 hover:text-navy-700">
                            {item.question}
                          </AccordionTrigger>
                          <AccordionContent className="text-gray-600 leading-relaxed pt-4">
                            {item.answer}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">{t.contact.title}</h2>
          <p className="text-xl text-gray-600 mb-12">{t.contact.subtitle}</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Phone */}
            <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6 text-navy-600" />
                </div>
                <p className="text-gray-600">{t.contact.phone}</p>
              </CardContent>
            </Card>

            {/* Email */}
            <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6 text-navy-600" />
                </div>
                <p className="text-gray-600">{t.contact.email}</p>
              </CardContent>
            </Card>

            {/* Meeting */}
            <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-6 w-6 text-navy-600" />
                </div>
                <Link href="/contact">
                  <Button className="bg-navy-600 hover:bg-navy-700">{t.contact.meeting}</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
